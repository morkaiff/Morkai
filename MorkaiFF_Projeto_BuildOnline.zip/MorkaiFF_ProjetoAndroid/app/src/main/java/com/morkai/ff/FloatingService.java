package com.morkai.ff;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Switch;

public class FloatingService extends Service {
    private WindowManager wm;
    private View bubble, panel;
    private WindowManager.LayoutParams bubbleParams, panelParams;
    private int purple = 0xFF8B4DFF;

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        int type = android.os.Build.VERSION.SDK_INT >= 26 ?
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        bubbleParams = new WindowManager.LayoutParams(76, 76, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        bubbleParams.gravity = Gravity.TOP | Gravity.LEFT;
        bubbleParams.x = 12; bubbleParams.y = 260;

        TextView skull = new TextView(this);
        skull.setText("💀");
        skull.setTextSize(34);
        skull.setGravity(Gravity.CENTER);
        skull.setTextColor(Color.WHITE);
        skull.setBackground(circle(0xFF101019, purple, 3));
        bubble = skull;
        bubble.setOnClickListener(v -> togglePanel());
        bubble.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int sx, sy;
            public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    dx=e.getRawX(); dy=e.getRawY(); sx=bubbleParams.x; sy=bubbleParams.y; return false;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    bubbleParams.x=sx+(int)(e.getRawX()-dx);
                    bubbleParams.y=sy+(int)(e.getRawY()-dy);
                    wm.updateViewLayout(bubble,bubbleParams); return true;
                }
                return false;
            }
        });
        wm.addView(bubble, bubbleParams);
    }

    private GradientDrawable circle(int color, int stroke, int sw) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL); d.setColor(color); d.setStroke(sw, stroke);
        return d;
    }
    private GradientDrawable rounded(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(36); d.setStroke(2, stroke); return d;
    }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private void togglePanel() {
        if (panel != null) { wm.removeView(panel); panel = null; return; }
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setPadding(20,16,20,16);
        box.setBackground(rounded(0xF5101019, purple));
        TextView head = text("💀  Morkai FF        ⊖", 20, 0xFFFFFFFF);
        head.setTypeface(null, Typeface.BOLD);
        box.addView(head, new LinearLayout.LayoutParams(270, 54));
        TextView sub = text("PAINEL PERSONALIZADO", 11, 0xFFBDA6FF);
        box.addView(sub);
        addSwitch(box, "Efeito neon");
        addSwitch(box, "Modo compacto");
        addSwitch(box, "Vibração ao tocar");
        TextView hide = text("Toque na caveira para esconder", 12, 0xFFBDA6FF);
        hide.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, 44);
        box.addView(hide, hp);
        panel = box;
        int type = android.os.Build.VERSION.SDK_INT >= 26 ?
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        panelParams = new WindowManager.LayoutParams(-2, -2, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.LEFT;
        panelParams.x = bubbleParams.x + 82; panelParams.y = bubbleParams.y;
        wm.addView(panel, panelParams);
    }
    private void addSwitch(LinearLayout parent, String label) {
        Switch sw = new Switch(this); sw.setText(label); sw.setTextColor(Color.WHITE);
        sw.setTextSize(14); sw.setPadding(4, 8, 4, 8); sw.setButtonTintList(android.content.res.ColorStateList.valueOf(purple));
        sw.setChecked(true);
        parent.addView(sw, new LinearLayout.LayoutParams(270, 48));
    }
    @Override public int onStartCommand(Intent i, int flags, int id) { return START_STICKY; }
    @Override public void onDestroy() {
        if (panel != null) wm.removeView(panel);
        if (bubble != null) wm.removeView(bubble);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }
}
